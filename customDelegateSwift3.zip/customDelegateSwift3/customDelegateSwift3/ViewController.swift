//
//  ViewController.swift
//  customDelegateSwift3
//
//  Created by PintLabs on 19/01/17.
//  Copyright © 2017 LostFrequencies. All rights reserved.
//

import UIKit

class ViewController: UIViewController, myDelegate {

    @IBOutlet weak var firstLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        let mc = secondViewController()
//        mc.delegate = self
    }
    // Delegate method
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func clickButtonAction(_ sender: Any) {
        if let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NewsDetailsVCID") as? secondViewController {
            viewController.delegate = self
            if let navigator = navigationController {
                navigator.pushViewController(viewController, animated: true)
            }
        }
    }
    func report(info: String) {
        print("delegate: \(info)")
        firstLabel.text = info
        
    }
    
}

