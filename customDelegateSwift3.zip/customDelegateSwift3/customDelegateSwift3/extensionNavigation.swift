//
//  extensionNavigation.swift
//  customDelegateSwift3
//
//  Created by PintLabs on 19/01/17.
//  Copyright © 2017 LostFrequencies. All rights reserved.
//

import UIKit

extension UINavigationController {
    func pop(animated: Bool) {
        _ = self.popViewController(animated: animated)
    }
    
    func popToRoot(animated: Bool) {
        _ = self.popToRootViewController(animated: animated)
    }
}
