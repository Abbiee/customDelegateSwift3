//
//  secondViewController.swift
//  customDelegateSwift3
//
//  Created by PintLabs on 19/01/17.
//  Copyright © 2017 LostFrequencies. All rights reserved.
//

import UIKit


protocol myDelegate {
    func report(info:String)
}


class secondViewController: UIViewController, UINavigationControllerDelegate {
    var delegate:myDelegate?

    @IBOutlet weak var textFiled: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        navigationController?.delegate = self
        
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    override func viewWillDisappear(_ animated: Bool) {
//        super.viewWillDisappear(animated)
//        if self.isBeingDismissed {

    @IBAction func goBackClickAction(_ sender: Any) {
        DispatchQueue.main.async
            {
                /*Write your code here*/
                self.delegate?.report(info: self.textFiled.text!)
        }
        navigationController?.pop(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func navigationController(_ navigationController: UINavigationController, willShow viewController: UIViewController, animated: Bool) {
        if viewController is ViewController {
                // Here you pass the data back to your original view controller
            DispatchQueue.main.async
                {
                    /*Write your code here*/
                    self.delegate?.report(info: self.textFiled.text!)
            }
        }
    }

}
